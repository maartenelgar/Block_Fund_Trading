from BinanceAPI import Client
from Keys.keys import API_keys



class Order_Manager(object):
 
    @staticmethod
    def buy_limit(symbol, quantity, buyPrice):



