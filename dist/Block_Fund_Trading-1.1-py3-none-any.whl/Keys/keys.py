"""
The Keys program contains the API username and password.
"""
class API_keys(object):
      def __init__(self, username, password)
      self.username = 'OfBLqIoRvQCloLCSc5lmrN5ikapHhDul27yn6TrsM5X7l0dkw64ME0ESkEkBatNL'
      self.password = '9Jwb6sR6z8N4jWlK9n0bZrHAeipA8FaYibl5VFnBoE0t3CmnY1CyVWKCekOmpg2r'
