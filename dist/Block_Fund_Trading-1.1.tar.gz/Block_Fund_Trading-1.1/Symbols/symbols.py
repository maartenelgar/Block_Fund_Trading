"""
defining all the symbols
"""
from BinanceAPI.client import Client


class Symbol(object):

     def __init__(self)
      self.ETHBTC = 'ETHBTC'
      self.


     def pair_scrapper():
           all_pairs = client.get_products()
           print(all_pairs)
           
     
     
