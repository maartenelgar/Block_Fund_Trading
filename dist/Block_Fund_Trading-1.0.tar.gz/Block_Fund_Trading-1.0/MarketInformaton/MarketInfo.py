"""
defining all the symbols
"""
from BinanceAPI.client import Client


class MarketInfo(object):

     def __init__(self)
      self.trade_fee = 0.01%
      self.


     
     
